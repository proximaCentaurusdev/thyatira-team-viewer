# Thyatira Team — Optional Electron Protected Wrapper

This is **not** a rebuild of the website. `index.html` stays exactly what
it is — a normal site that works in any browser. This folder is a thin,
optional wrapper: an Electron window that loads that same `index.html`
and adds one native capability a browser tab cannot grant itself —
Windows-level content protection — turned on only while a video is
actually playing.

## What this is / is not

| | |
|---|---|
| **Is** | A `BrowserWindow` pointed at your existing site, plus a 2-line IPC bridge |
| **Is not** | A desktop rewrite of the UI. No screens, styles, or components are reimplemented here. |
| **Runs** | `index.html`'s own JS unmodified — same Firestore auth, same session/access-code logic, same watermark, same Protected Video Mode, same capture-key deterrence already in the site |
| **Adds** | `win.setContentProtection(true/false)`, toggled by the page itself at the exact moments Protected Video Mode starts/stops |

The website must keep working identically with this wrapper deleted
entirely — nothing in `index.html`'s core behavior depends on
`window.electronAPI` existing; it's checked with a plain `if` and is a
no-op everywhere else (Chrome, Edge, Safari, mobile browsers, the Flutter
app's WebView, etc.).

## Setup

```bash
cd electron
npm install
npm start                 # loads ../index.html locally
# or, once your site is deployed:
THYATIRA_URL=https://your-deployed-site.example.com npm start
```

To build a distributable Windows installer:

```bash
npm run dist:win
```

## How the toggle works

1. `index.html` already tracks `protectedModeActive` — true exactly while
   a video is in the `PLAYING` state (see `onPlayerStateChange` in the
   site's own JS; this was not changed).
2. Three small hooks were added at the existing PLAYING / PAUSED / ENDED
   transitions, plus `closeVideo()` as a safety net, each calling
   `window.electronAPI.setVideoProtection(true|false)` if that API exists.
3. `preload.js` forwards that call over IPC to `main.js`.
4. `main.js` calls `win.setContentProtection(enabled)` and reports back
   whether the call succeeded (not *which* Windows capture-affinity flag
   Electron applied internally — see below for why that distinction
   matters and why this can't confirm it).
5. The page shows a small "Windows Content Protection Active" badge in
   the video top bar **only** when running inside Electron with
   protection currently on — a normal browser tab never shows this,
   because it would be false to claim.

Protection is never on by default and never left on when nothing is
playing — it starts `false` in `createWindow()`, turns on only on
`PLAYING`, and turns off on `PAUSED`, `ENDED`, or the viewer closing.

## What Windows content protection actually does — and doesn't

`win.setContentProtection(true)` calls `SetWindowDisplayAffinity` on
Windows under the hood. Depending on your Electron version and the
Windows build the user is running, that resolves to one of two flags:

- **`WDA_EXCLUDEFROMCAPTURE`** (Windows 10 version 2004+, and only on
  Electron versions that request it) — the window is excluded from most
  screen-capture APIs: Win32 GDI capture, most third-party screen
  recorders, most "share your screen" features in conferencing apps.
- **`WDA_MONITOR`** (older Windows, or older Electron behavior) — a
  weaker, legacy flag that does **not** exclude the window from capture
  the same way; it exists mainly for compatibility.

Electron decides internally which one applies and does not report that
choice back to the renderer, so `index.html`'s badge intentionally says
only "Content Protection Active" — it does not claim a specific
guarantee level it can't verify. **Check your installed Electron
version's release notes against the target Windows build** if you need
to know for certain which flag your users are getting; this has changed
across Electron versions and this file was written without the ability
to browse Electron's current documentation, so treat the version pinned
in `package.json` as a starting point to verify, not a guarantee.

**What this can never do, on any Electron/Windows combination:**

- Stop a phone or camera pointed at the screen.
- Stop capture on macOS/Linux (this feature is Windows-specific;
  `setContentProtection` is close to a no-op for capture-blocking
  purposes on other OSes, though it does still run without erroring).
- Provide real DRM. This is not Widevine/PlayReady-level protection —
  there is no encrypted, licensed video pipeline here. It is a native
  window-visibility flag, nothing more.
- Guarantee protection on every Windows machine — older Windows builds,
  certain GPU drivers, or remote-desktop/virtual-machine environments can
  all reduce or bypass the effect.

**What it's honestly good for:** blocking the common, casual
capture paths (screenshot tools, OBS/most recorders, most screen-share)
on a reasonably current Windows 10/11 machine — genuinely stronger than
anything a browser tab alone can offer, but a deterrent layered on top of
the site's existing watermark and Protected Video Mode, not a replacement
guarantee. This matches how `index.html` already talks about its
browser-side protections — nothing here should ever be presented to
users as "capture-proof."

## Files

```
electron/
  main.js       BrowserWindow + the single IPC handler
  preload.js    contextBridge — exposes window.electronAPI.setVideoProtection only
  package.json  electron-builder config for a Windows installer
index.html       UNCHANGED except for the small additive hooks described above
                  (search for "ELECTRON BRIDGE" in its <script> to see all of them)
```
